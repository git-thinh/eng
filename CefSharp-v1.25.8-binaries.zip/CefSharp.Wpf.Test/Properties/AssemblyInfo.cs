﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("CefSharp.Wpf.Test")]
[assembly: AssemblyCompany("The CefSharp Project")]
[assembly: AssemblyProduct("CefSharp")]
[assembly: AssemblyCopyright("Copyright © The CefSharp Project 2013")]

[assembly: AssemblyVersion("1.25.8.0")]
[assembly: ComVisible(false)]
