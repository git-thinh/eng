﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("CefSharp.Example")]
[assembly: AssemblyCompany("The CefSharp Project")]
[assembly: AssemblyProduct("CefSharp.Example")]
[assembly: AssemblyCopyright("Copyright © The CefSharp Project 2013")]

[assembly: AssemblyVersion("1.25.8.0")]
[assembly: ComVisible(false)]
