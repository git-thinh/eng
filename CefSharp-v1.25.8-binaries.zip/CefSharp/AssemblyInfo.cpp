#include "Stdafx.h"

using namespace System;
using namespace System::Reflection;
using namespace System::Runtime::CompilerServices;
using namespace System::Runtime::InteropServices;
using namespace System::Security::Permissions;

[assembly:AssemblyTitle("CefSharp")];
[assembly:AssemblyCompany("The CefSharp Project")];
[assembly:AssemblyProduct("CefSharp")];
[assembly:AssemblyCopyright("Copyright (c) The CefSharp Project 2013")];

[assembly:AssemblyVersion("1.25.8.0")];
[assembly:ComVisible(false)];
[assembly:CLSCompliant(true)];
[assembly:SecurityPermission(SecurityAction::RequestMinimum, UnmanagedCode = true)];
